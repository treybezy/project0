
public interface Functional {
	
	String function(); 

}
