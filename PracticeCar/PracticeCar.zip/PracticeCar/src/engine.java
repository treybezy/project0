
public class engine extends CarPart{
	
	int gears = 4;

}
