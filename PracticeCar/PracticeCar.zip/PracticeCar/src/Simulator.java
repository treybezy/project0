
public class Simulator {

	public static void main(String[] args) {
		
		run carObject = new Car();
		carObject.run();

	}

}

