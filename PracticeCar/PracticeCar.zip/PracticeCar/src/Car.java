
public class Car {

	public void run() {
		System.out.println("The run method");
	}

}
