
public class fuelTank extends CarPart{
	
	int gallons = 12;

}
