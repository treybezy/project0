
public class wheels extends CarPart{
	int tires = 4;

}
