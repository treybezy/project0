
public class CarPart implements Functional {
	
	int condition = 0;
	
	public static status(condition) {
		if (condition == 0) {
			System.out.println("damaged")
		} else {
			System.out.println("may need repairs")
		}
	}

}
